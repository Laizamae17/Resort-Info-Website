<?php
        include 'views/header.php';
        ?>

<main>
    <br>
    <h1> About Us </h1>
    <br>
    <p>Welcome to Resort Info, your ultimate online destination for discovering the best resorts in the Philippines! Our mission is to provide travelers with comprehensive and up-to-date information about various resorts, helping you find the perfect getaway that suits your needs and preferences.
At Resort info, we understand that planning a vacation can be overwhelming. That's why we've curated a diverse selection of resorts, from serene beach side retreats to luxurious mountain escapes. Our user-friendly platform offers detailed descriptions, stunning images, and essential information about each resort, including amenities, accommodations, dining options, and nearby attractions.
Whether you're looking for a family-friendly resort, a romantic hideaway, or an adventure-filled escape, we have something for everyone. Our team of travel enthusiasts is dedicated to researching and reviewing resorts to ensure you have all the information you need to make informed decisions.
We believe that every traveler deserves a memorable experience, and our goal is to inspire you to explore the beauty and diversity of the Philippines. Join us as we embark on a journey to uncover hidden gems and popular destinations, making your travel planning as enjoyable as the trip itself.
Thank you for choosing Resort Info. We look forward to helping you create unforgettable memories at your next resort getaway! </p> 
    
</main>
<?php include 'views/footer.php';
?>