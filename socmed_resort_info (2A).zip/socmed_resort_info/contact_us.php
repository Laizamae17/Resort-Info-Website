<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $message = htmlspecialchars($_POST["message"]);
    
    if (!empty($name) && !empty($email) && !empty($message)) {
        $to = "yourresort@email.com"; // Change this to your actual email
        $subject = "New Contact Form Submission";
        $headers = "From: $email\r\n" . "Reply-To: $email\r\n";
        
        $body = "Name: $name\nEmail: $email\nMessage:\n$message";
        
        if (email($to, $subject, $body, $headers)) {
            $success = "Your message has been sent successfully!";
        } else {
            $error = "Oops! Something went wrong. Please try again later.";
        }
    } else {
        $error = "All fields are required!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="./res/mystyle.css" rel="stylesheet" type="text/css"/>
    <title>Contact Us - Resort Info</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 50px;background-color: #00ccff; }
        .container { max-width: 500px; margin: auto; }
        input, textarea { width: 100%; padding: 10px; margin: 10px 0; }
        .btn { background: #008CBA; color: white; border: none; padding: 10px; cursor: pointer; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Contact Us</h2>
        <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        <form method="POST" action="">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" placeholder="Your Message" rows="5" required></textarea>
            <button type="submit" class="btn">Send Message</button>
        </form>
    </div>
</body>
</html>


<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="./res/mystyle.css" rel="stylesheet" type="text/css"/>