<?php 
include 'views/header.php';  
?>

<main>
    <h1>Gallery</h1>
    <br>
    <p>Check out the beautiful resorts here!</p>
    <br>
 
    <div class="gallery">
        <div class="gallery-item">
            <p>PARK PLACE RESORT</p>
            <img src="gallery_images/picture7.jpg" alt="Park Place Resort"/>
            <a href="resort_details.php?resort=park_place">View Details</a>
        </div>
        
        <div class="gallery-item">
            <p>ACAPULCO RESORT</p>
            <img src="gallery_images/picture1.jpg" alt="Acapulco Resort"/>
            <a href="resort_details.php?resort=acapulco">View Details</a>
        </div>
        
        <div class="gallery-item">
            <p>HIDDEN VALLEY RESORT</p>
            <img src="gallery_images/picture4.jpg" alt="Hidden Valley Resort"/>
            <a href="resort_details.php?resort=hidden_valley">View Details</a>
        </div>

        <div class="gallery-item">
            <p>LA BRIZA RESORT</p>
            <img src="gallery_images/picture2.jpg" alt="La Briza Resort"/>
            <a href="resort_details.php?resort=la_briza">View Details</a>
        </div>

        <div class="gallery-item">
            <p>ESTRELLA DEL MAR RESORT</p>
            <img src="gallery_images/picture14.jpg" alt="Estela del Mar Resort"/>
            <a href="resort_details.php?resort=estrella_del_mar">View Details</a>
        </div>

        <div class="gallery-item">
            <p>OCEAN BREEZE RESORT</p>
            <img src="gallery_images/picture15.jpg" alt="Ocean Breeze Resort"/>
            <a href="resort_details.php?resort=ocean_breeze">View Details</a>
        </div>
        
         <div class="gallery-item">
            <p>LIBO SPRING RESORT</p>
            <img src="gallery_images/picture13.jpg" alt="Libo Spring Resort"/>
            <a href="resort_details.php?resort=libo_spring">View Details</a>
        </div>
        
        <div class="gallery-item">
            <p>MARMIL RESORT</p>
            <img src="gallery_images/picture5.jpg" alt="Marmil Resort"/>
            <a href="resort_details.php?resort=marmil">View Details</a>
        </div>
        
        <div class="gallery-item">
            <p>ESTELA GRANDE RESORT</p>
            <img src="gallery_images/picture12.jpg" alt="Estela Grande Resort"/>
            <a href="resort_details.php?resort=estela_grande">View Details</a>
        </div>
        
        <div class="gallery-item">
            <p>THE RANCH RESORT</p>
            <img src="gallery_images/picture11.jpg" alt=""/>
            <a href="resort_details.php?resort=the_ranch">View Details</a>
        </div>
        
        <div class="gallery-item">
            <p>HIDDEN VALLEY BEACH RESORT</p>
            <img src="gallery_images/picture10.jpg" alt="Hidden Valley Beach Resort"/>
           <a href="resort_details.php?resort=hidden_valley_beach">View Details</a>
        </div>
        
    </div>
</main>

<?php include 'views/footer.php';

?>

        
    