<?php

function create_connection(){
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "socmed_resort_info";
    
    return new mysqli($host, $username, $password, $database);
}

