<?php
        include 'views/header.php';
        ?> 
        echo "Home";
        
<html>
    <head>
        <meta charset="UTF-8">
        <title>Socmed</title>
        <link href="./res/mystyle.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
 
<main>
    <br>
    <h1>WELCOME TO RESORT INFO </h1>
    <br>
    <p> Your one-stop destination for all resort-related information. Explore our gallery, learn about our services, and find the perfect getaway!</p> 
    
    <div class="footer">
     
    <p>&copy; 2025 Resort Info. All rights reserved.</p>
 </div>
    <br>
    
   </main>
 </body>
</html>
