<?php
include 'views/header.php';

echo "Profile";

include 'views/footer.php';
?>
