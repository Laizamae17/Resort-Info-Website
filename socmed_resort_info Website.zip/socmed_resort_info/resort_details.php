<?php 
include 'views/header.php';  


$resort = isset($_GET['resort']) ? $_GET['resort'] : 'unknown';


$resorts = [
    'park_place' => [
        'name' => 'Park Place Resort', 
        'location' => 'Tajao, Pinamungajan, Cebu, Philippines',
        'description' => 'Park Place Beach Resort, located in Tajao, Pinamungajan, Cebu, offers a tranquil getaway with various amenities. It features 17 rooms, a swimming pool, beach access, and day cottages, making it ideal for relaxation and family gatherings. For inquiries, you can contact them at 032-468-8155..',
        'image' => 'gallery_images/picture7.jpg',
        'guest_reviews' => 'Rated 8.5/10 - Guests love the spacious rooms and friendly staff.'
    ],
    'acapulco' => [
        'name' => 'Acapulco Resort', 
        'location' => 'Ibo, Toledo City, Cebu, Philippines',
        'description' => 'Acapulco Resort in Ibo, Toledo City, offers a welcoming atmosphere with various amenities for guests. It features comfortable accommodations, a restaurant, outdoor swimming pools, and free Wi-Fi, making it suitable for both relaxation and family activities.',
        'image' => 'gallery_images/picture1.jpg',
        'distance' => [
            'Temple of Leah' => '26 miles',
            'Colon Street' => '29 miles',
            'Magellan\'s Cross' => '30 miles',
            'Mactan-Cebu International Airport' => '36 miles'
        ],
        'accommodations' => [
            'Standard Room' => 'Good for 2 - ₱2,950 per night',
            'One-Bedroom Suite' => 'Good for 2 - ₱3,600 per night',
            'Two-Bedroom Suite' => 'Good for 6 - ₱6,400 per night'
        ],
        'facilities' => [
            'Outdoor Pool', 
            'Private Beachfront', 
            'Restaurant & Bar', 
            'Airport Shuttle Service'
        ],
        'guest_reviews' => 'Rated 8.1/10 - Guests love the clean rooms, friendly staff, and great sunset views.'
    ],
    'hidden_valley' => [
        'name' => 'Hidden Valley Resort', 
        'location' => ' Lamac, Pinamungajan, Cebu, Philippines',
        'description' => 'Hidden Valley Wave Pool Resort in Pinamungajan, Cebu, features one of the largest wave pools in the Visayas, with a 4,000-square-meter area and waves suitable for all ages. The resort offers various accommodations, including 45 rooms, and additional attractions like a zipline and sky bike for adventure seekers.',
        'image' => 'gallery_images/picture4.jpg',
        'facilities' => [
            'Hiking Trails', 
            'Hot Springs', 
            'Eco-Friendly Accommodations'
        ],
        'guest_reviews' => 'Rated 8.7/10 - Ideal for relaxation and adventure.'
    ],
    'la_briza' => [
        'name' => 'La Briza Resort', 
        'location' => 'Tajao, Pinamungajan, Cebu, Philippines',
        'description' => 'La Briza Beach Resort, located in Tajao, Pinamungajan, Cebu, offers a relaxing ambiance and beach access. It features a mix of native and modern designs, with day and night use rates available. For inquiries and reservations, you can contact them at (0991) 634 3052 or (032) 238 5544. ',
        'image' => 'gallery_images/picture2.jpg',
        'facilities' => [
            'Private Beach', 
            'Scuba Diving & Snorkeling', 
            'Beachfront Bar'
        ],
        'guest_reviews' => 'Rated 9.0/10 - Best for couples and honeymooners.'
    ],
    'ocean_breeze' => [
        'name' => 'Ocean Breeze Resort', 
        'location' => 'Cabitoonan, Toledo City, Philippines',
        'description' => 'Resort featuring a private beach, adult and children,and a full-service spa and  making it a relaxing destination for guests.',
        'image' => 'gallery_images/picture15.jpg',
        'facilities' => [
            'Jacuzzi & Spa', 
            'Outdoor Pool', 
            'Water Sports Activities'
        ],
        'guest_reviews' => 'Rated 9.2/10 - Great for families and beach lovers.'
    ],
    'the_ranch' => [
        'name' => 'The Ranch Resort', 
        'location' => 'Barangay Bato, Toledo City, Philippines',
        'description' => 'The Ranch Resort in Bato, Toledo City, is a family-friendly destination featuring seven pools, ziplining, horseback riding, and ATV rides. It offers accommodations with air-conditioned rooms and a restaurant, making it ideal for outings and events.',
        'image' => 'gallery_images/picture11.jpg',
        'facilities' => [
            'Horseback Riding', 
            'ATV Tours', 
            'Nature Trails'
        ],
        'guest_reviews' => 'Rated 8.9/10 - Perfect for adventure seekers and families.'
    ],
 'estrella_del_mar' => [
        'name' => 'Estrella del Mar Resort',
        'location' => ' Ibo, Toledo City, Philippines',
        'description' => 'Estrella del Mar Resort in Ibo, Toledo City, offers a tranquil escape with beautiful sea views. It features a restaurant serving Filipino and international cuisine, and provides comfortable accommodations, making it suitable for both relaxation and dining experiences. ',
        'image' => 'gallery_images/picture14.jpg',
        'facilities' => [
            'Ocean-view rooms', 
            'Beachside dining', 
            'Swimming pools'
        ],
        'guest_reviews' => 'Rated 8.8/10 - Perfect for beach lovers and relaxation.'
    ],
    'libo_spring' => [
        'name' => 'Libo Spring Resort',
        'location' => 'Pinamungajan, Cebu, Philippines',
        'description' => 'Libo Spring Resort in Pinamungajan, Cebu, is a natural spring mountain resort featuring a spring-fed swimming pool that is chlorine-free and utilizes clean, flowing water. It is a popular destination for family outings, offering a refreshing escape in a scenic environment. ',
        'image' => 'gallery_images/picture13.jpg',
        'facilities' => [
            'Natural spring pools', 
            'Cottages for day-use and overnight stays', 
            'Picnic areas'
        ],
        'guest_reviews' => 'Rated 8.5/10 - A perfect getaway for nature lovers.'
    ],
    'marmil' => [
        'name' => 'Marmil Resort',
        'location' => 'Toledo City, Cebu, Philippines',
        'description' => 'Marmil Resort in Toledo City, Cebu, is a vibrant destination that combines a resort, restaurant, and restobar, offering both local and international cuisine. Located in Toledo Poblacion, it provides a relaxing atmosphere for visitors looking to unwind and enjoy good food. ',
        'image' => 'gallery_images/picture5.jpg',
        'facilities' => [
            'Swimming pools for kids and adults',
            'Recreational play areas',
            'Affordable room rates'
        ],
        'guest_reviews' => 'Rated 8.2/10 - Affordable and fun for the whole family.'
    ],
    'estela_grande' => [
        'name' => 'Estela Grande Resort',
        'location' => 'Upper Dakit, Cabitoonan, Toledo City, Cebu, Philippines',
        'description' => 'Estela Grande Resort, located in Upper Dakit, Cabitoonan, Toledo City, Cebu, is a scenic getaway offering stunning mountain views. It features amenities such as a pool and is designed for relaxation, making it an ideal spot for visitors looking to unwind in a tranquil environment. ',
        'image' => 'gallery_images/picture12.jpg',
        'facilities' => [
            'High-end suites',
            'Event and banquet halls',
            'Fine dining options'
        ],
        'guest_reviews' => 'Rated 9.0/10 - Luxury and comfort combined.'
    ],
    'hidden_valley_beach' => [
        'name' => 'Hidden Valley Beach Resort',
        'location' => 'Tajao, Pinamungajan, Cebu, Philippines',
        'description' => 'Hidden Valley Beach Resort, located in Tajao, Pinamungajan, Cebu, offers a beachfront experience with stunning ocean views. Managed by the Lamac Multipurpose Cooperative, it features amenities like a swimming pool and a restaurant, making it a great destination for relaxation and family gatherings. ',
        'image' => 'gallery_images/picture10.jpg',
        'facilities' => [
            'Direct beach access',
            'Water sports and boat rentals',
            'Beachfront cottages'
        ],
        'guest_reviews' => 'Rated 8.7/10 - Great beachfront experience with exciting water activities.'
    ]
];


if (array_key_exists($resort, $resorts)) {
    $resort_data = $resorts[$resort];
} else {
    $resort_data = [
        'name' => 'Resort Not Found',
        'description' => 'Sorry, the resort you are looking for does not exist.',
        'image' => 'gallery_images/default.jpg'
    ];
}
?>

<main>
    <h1><?php echo $resort_data['name']; ?></h1>
    <img src="<?php echo $resort_data['image']; ?>" alt="<?php echo $resort_data['name']; ?>" style="width: 100%; max-width: 300px; border-radius: 10px;">
    <p><?php echo $resort_data['description']; ?></p>

    <?php if (isset($resort_data['location'])): ?>
        <p><strong>Location:</strong> <?php echo $resort_data['location']; ?></p>
    <?php endif; ?>

    <?php if (isset($resort_data['distance'])): ?>
        <h3>Nearby Attractions</h3>
        <ul>
            <?php foreach ($resort_data['distance'] as $place => $miles): ?>
                <li><?php echo "$place: $miles away"; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (isset($resort_data['accommodations'])): ?>
        <h3>Accommodations</h3>
        <ul>
            <?php foreach ($resort_data['accommodations'] as $type => $price): ?>
                <li><?php echo "$type - $price"; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (isset($resort_data['facilities'])): ?>
        <h3>Facilities & Amenities</h3>
        <ul>
            <?php foreach ($resort_data['facilities'] as $facility): ?>
                <li><?php echo $facility; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (isset($resort_data['guest_reviews'])): ?>
        <h3>Guest Reviews</h3>
        <p><?php echo $resort_data['guest_reviews']; ?></p>
    <?php endif; ?>

    <a href="gallery.php" style="
        display: inline-block; 
        margin-top: 10px; 
        padding: 10px 20px; 
        background-color: #3498db; 
        color: white; 
        text-decoration: none; 
        border-radius: 5px;
        font-weight: bold;
    ">⬅ Back to Gallery</a>
</main>

<?php include 'views/footer.php'; ?>

