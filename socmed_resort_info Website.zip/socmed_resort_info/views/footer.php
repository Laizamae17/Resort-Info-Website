</body>
 <div class="footer">
     
    <p>&copy; 2025 Resort Info. All rights reserved.</p>
 </div>
</html>
